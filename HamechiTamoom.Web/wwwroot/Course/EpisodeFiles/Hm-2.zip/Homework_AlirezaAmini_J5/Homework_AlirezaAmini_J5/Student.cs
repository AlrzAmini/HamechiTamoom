﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_AlirezaAmini_J5
{
    public class Student
    {
        private string Name;
        private string Family;
        private string SID;

        public string name
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }
        public string family
        {
            get
            {
                return Family;
            }
            set
            {
                Family = value;
            }
        }
        public string sid
        {
            get
            {
                return SID;
            }
            set
            {
                SID = value;
            }
        }
    }
}
