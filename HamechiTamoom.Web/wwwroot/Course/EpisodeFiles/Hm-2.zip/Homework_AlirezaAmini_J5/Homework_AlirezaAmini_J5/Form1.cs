﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework_AlirezaAmini_J5
{
    public partial class Form1 : Form
    {
        List<Student> lstStudent = new List<Student>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "هوم ورک جلسه پنج علیرضا امینی نسب";
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            Student S1 = new Student();
            S1.name = TxtName.Text;
            S1.family = TxtFamily.Text;
            S1.sid = TxtSID.Text;

            lstStudent.Add(S1);
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            foreach (var item in lstStudent)
            {
                MessageBox.Show(item.name + " - " + item.family + " - " + item.sid);
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            // find students where their namea are : txtsearch
            List<Student> result = lstStudent.FindAll(s => s.family == TxtSearch.Text);

            if (result.Count == 0)
            {
                string NotFound = "NotFound";
                MessageBox.Show(NotFound, "خالی");
            }
            else
            {
                foreach (var item in result)
                {
                    MessageBox.Show("Founded =>  Family : " + item.family + "  Name : " + item.name + "  Sid : " + item.sid);
                }
            }
        }
    }
}
