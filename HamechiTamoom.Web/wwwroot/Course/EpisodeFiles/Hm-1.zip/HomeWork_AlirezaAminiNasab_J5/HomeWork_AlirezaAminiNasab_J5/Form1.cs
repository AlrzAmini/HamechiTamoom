﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork_AlirezaAminiNasab_J5
{
    public partial class Form1 : Form
    {
        Dictionary<string, Student> dicStudents = new Dictionary<string, Student>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "هوم ورک جلسه پنج علیرضا امینی نسب";
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            Student S1 = new Student();
            S1.name = TxtName.Text;
            S1.family = TxtFamily.Text;
            S1.sid = TxtSID.Text;

            dicStudents.Add(S1.sid,S1);
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            foreach (var item in dicStudents.Values)
            {
                MessageBox.Show(item.name + " - " + item.family);
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            // find students where their namea are : txtsearch
            bool IsValid = dicStudents.ContainsKey(TxtSearch.Text);

            if (IsValid)
            {
                MessageBox.Show("Founded");
            }
            else
            {
                MessageBox.Show("Not Founded");
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
