﻿
namespace Jlse5_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnShow = new System.Windows.Forms.Button();
            this.BtnRun = new System.Windows.Forms.Button();
            this.BtnRemoveAll = new System.Windows.Forms.Button();
            this.TxtSearchName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.BtnDictionary = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnShow
            // 
            this.BtnShow.BackColor = System.Drawing.SystemColors.Info;
            this.BtnShow.Location = new System.Drawing.Point(161, 12);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(143, 139);
            this.BtnShow.TabIndex = 0;
            this.BtnShow.Text = "Show";
            this.BtnShow.UseVisualStyleBackColor = false;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // BtnRun
            // 
            this.BtnRun.BackColor = System.Drawing.SystemColors.Info;
            this.BtnRun.Location = new System.Drawing.Point(12, 12);
            this.BtnRun.Name = "BtnRun";
            this.BtnRun.Size = new System.Drawing.Size(143, 139);
            this.BtnRun.TabIndex = 1;
            this.BtnRun.Text = "Run";
            this.BtnRun.UseVisualStyleBackColor = false;
            this.BtnRun.Click += new System.EventHandler(this.BtnRun_Click);
            // 
            // BtnRemoveAll
            // 
            this.BtnRemoveAll.BackColor = System.Drawing.SystemColors.Info;
            this.BtnRemoveAll.Location = new System.Drawing.Point(310, 12);
            this.BtnRemoveAll.Name = "BtnRemoveAll";
            this.BtnRemoveAll.Size = new System.Drawing.Size(143, 139);
            this.BtnRemoveAll.TabIndex = 2;
            this.BtnRemoveAll.Text = "RemoveAll";
            this.BtnRemoveAll.UseVisualStyleBackColor = false;
            this.BtnRemoveAll.Click += new System.EventHandler(this.BtnRemoveAll_Click);
            // 
            // TxtSearchName
            // 
            this.TxtSearchName.Location = new System.Drawing.Point(478, 30);
            this.TxtSearchName.Name = "TxtSearchName";
            this.TxtSearchName.Size = new System.Drawing.Size(153, 23);
            this.TxtSearchName.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(564, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "جستجوی نام";
            // 
            // BtnSearch
            // 
            this.BtnSearch.BackColor = System.Drawing.SystemColors.Info;
            this.BtnSearch.Location = new System.Drawing.Point(478, 63);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(153, 31);
            this.BtnSearch.TabIndex = 5;
            this.BtnSearch.Text = "Search";
            this.BtnSearch.UseVisualStyleBackColor = false;
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // BtnDictionary
            // 
            this.BtnDictionary.BackColor = System.Drawing.SystemColors.Info;
            this.BtnDictionary.Location = new System.Drawing.Point(656, 8);
            this.BtnDictionary.Name = "BtnDictionary";
            this.BtnDictionary.Size = new System.Drawing.Size(143, 139);
            this.BtnDictionary.TabIndex = 6;
            this.BtnDictionary.Text = "DictionaryTst";
            this.BtnDictionary.UseVisualStyleBackColor = false;
            this.BtnDictionary.Click += new System.EventHandler(this.BtnDictionary_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 159);
            this.Controls.Add(this.BtnDictionary);
            this.Controls.Add(this.BtnSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtSearchName);
            this.Controls.Add(this.BtnRemoveAll);
            this.Controls.Add(this.BtnRun);
            this.Controls.Add(this.BtnShow);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Button BtnRun;
        private System.Windows.Forms.Button BtnRemoveAll;
        private System.Windows.Forms.TextBox TxtSearchName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnSearch;
        private System.Windows.Forms.Button BtnDictionary;
    }
}

