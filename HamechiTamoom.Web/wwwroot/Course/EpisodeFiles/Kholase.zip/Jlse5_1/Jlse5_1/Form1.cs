﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jlse5_1
{
    public partial class Form1 : Form
    {
        List<Student> Stu = new List<Student>();
        Dictionary<int, string> dicName = new Dictionary<int, string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnRun_Click(object sender, EventArgs e)
        {
            // test list
            List<string> Str = new List<string>();
            Str.Add("AliReza");

            Student S1 = new Student();
            S1.sid = 1547;
            S1.name = "alireza";
            Stu.Add(S1);

            Student S2 = new Student();
            S2.sid = 2658;
            S2.name = "mohammad";
            Stu.Add(S2);

            Student S3 = new Student();
            S3.sid = 4448;
            S3.name = "Zahra";
            Stu.Insert(0,S3);

            // contains test
            bool IsExist = Stu.Contains(S2);

            // take index of S2
            int Index = Stu.IndexOf(S2);

            
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            if (Stu.Count == 0)
            {
                string ep = "Empty";
                MessageBox.Show(ep,"خالی");
            }
            else
            {
                foreach (var item in Stu)
                {
                    MessageBox.Show(item.name + " : " + item.sid);
                }
            }
        }

        private void BtnRemoveAll_Click(object sender, EventArgs e)
        {
            Stu.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "جلسه 5";
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            // find students where their namea are : alireza
            List<Student> result = Stu.FindAll(s => s.name == TxtSearchName.Text);

            if (result.Count == 0)
            {
                string NotFound = "NotFound";
                MessageBox.Show(NotFound, "خالی");
            }
            else
            {
                foreach (var item in result)
                {
                    MessageBox.Show("Founded : " + item.name);
                }
            }
        }

        private void BtnDictionary_Click(object sender, EventArgs e)
        {
            dicName.Add(1,"hadi");
            dicName.Add(2,"amir");
            dicName.Add(3,"amir");

            // Will Failed
            dicName.Add(2,"mina");
        }
    }
}
