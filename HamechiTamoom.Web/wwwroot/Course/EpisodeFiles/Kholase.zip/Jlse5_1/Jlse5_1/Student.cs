﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jlse5_1
{
    public class Student
    {
        private int SID;
        private string Name;

        public int sid
        {
            get
            {
                return SID;
            }
            set
            {
                SID = value;
            }
        }
        public string name
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }
    }
}
